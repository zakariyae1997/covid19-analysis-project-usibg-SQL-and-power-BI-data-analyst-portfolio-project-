SELECT *
  FROM [PortfolioProject1].[dbo].[CovidDeaths$]
  where continent is not null
  order by 3,4

  --SELECT *
  --FROM [PortfolioProject1].[dbo].[CovidVaccinations$]
  --order by 3,4

--the data that we are to be using

Select location, date, total_cases, new_cases, total_deaths, new_deaths,population
  FROM [PortfolioProject1].[dbo].[CovidDeaths$]
  where continent is not null
  order by 1,2


--Looking at totale cases vs total deaths
Select location, date, total_cases, total_deaths, (total_deaths/total_cases)*100 as Deathspercentage
  FROM [PortfolioProject1].[dbo].[CovidDeaths$]
  where location like '%morocco%' and total_cases is not null
  and continent is not null
  order by 1,2

--Looking at totale cases vs Population
Select location, date,total_cases,population, (total_cases/population)*100 as Casespercentage
  FROM [PortfolioProject1].[dbo].[CovidDeaths$]
  where location like '%morocco%' and total_cases is not null 
  order by 1,2

--countries with highest infection rate/population
Select location ,population,MAX(total_cases) as highestinfection, (MAX(total_cases)/population)*100 as percentageofpopulationinfected
  FROM [PortfolioProject1].[dbo].[CovidDeaths$]
  where location like '%morocco%' and continent is not null
  --where continent is not null
  group by location, population
  order by percentageofpopulationinfected desc

  --countries with highest infection rate/population by date
Select location ,population, date, total_cases, ( total_cases / population) * 100 as percentageofpopulationinfected
--MAX(total_cases) as highestinfection, (MAX(total_cases)/population)*100 as percentageofpopulationinfected
  FROM [PortfolioProject1].[dbo].[CovidDeaths$]
  where continent is not null
  ORDER BY 1,3
  --group by location, population
  --order by percentageofpopulationinfected desc

--Showing countries with highest death count per population
Select location,MAX(cast(total_deaths as int)) as Totadeathcount
  FROM [PortfolioProject1].[dbo].[CovidDeaths$]
  where continent is not null
  group by location
  order by Totadeathcount desc




--countries with highest deaths rate/population
Select location ,population ,MAX(cast(total_deaths as int)) as highestdead, (MAX(cast(total_deaths as int))/population)*100 as percentageofpopulationdead
  FROM [PortfolioProject1].[dbo].[CovidDeaths$]
  where continent is not null
  group by location, population
  order by percentageofpopulationdead desc

  --by continent
Select continent ,MAX(cast(total_deaths as int)) as Totadeathcount
  FROM [PortfolioProject1].[dbo].[CovidDeaths$]
  where continent is not null
  group by continent
  order by Totadeathcount desc

--Total numbers
Select SUM(new_cases) as total_cases, SUM ( cast(new_deaths as int)) as total_deaths , 
SUM ( cast(new_deaths as int))/SUM(new_cases) as Deathspercentage
  FROM [PortfolioProject1].[dbo].[CovidDeaths$]
  where continent is not null
  --group by date
  --order by 1,2

--showing the continent with the highest death per population

SELECT dea.continent, dea.location, dea.date, dea.population, vac.new_vaccinations--dea.total_cases, dea.new_cases, dea.total_deaths, dea.new_deaths, dea.new_tests, dea.total_tests, dea.positive_rate, vac.total_vaccinations, vac.new_vaccinations, dea.population
, sum(cast(vac.new_vaccinations as int)) over (partition by dea.location order by dea.location,dea.date) as Rollingpeoplevaccinated
FROM [PortfolioProject1].[dbo].[CovidDeaths$] as dea
join [PortfolioProject1].[dbo].[CovidVaccinations$] as vac
  on dea.location =  vac.location 
  and dea.date =  vac.date
where dea.continent is not null
order by 2,3

--using CTE

with popvsvac ( continent, location, date, population, new_vaccinations, Rollingpeoplevaccinated)
as
(
SELECT dea.continent, dea.location, dea.date, dea.population, vac.new_vaccinations--dea.total_cases, dea.new_cases, dea.total_deaths, dea.new_deaths, dea.new_tests, dea.total_tests, dea.positive_rate, vac.total_vaccinations, vac.new_vaccinations, dea.population
, sum(cast(vac.new_vaccinations as int)) over (partition by dea.location order by dea.location,dea.date) as Rollingpeoplevaccinated
FROM [PortfolioProject1].[dbo].[CovidDeaths$] as dea
join [PortfolioProject1].[dbo].[CovidVaccinations$] as vac
  on dea.location =  vac.location 
  and dea.date =  vac.date
where dea.continent is not null
)

SELECT *, (Rollingpeoplevaccinated/population)*100
from popvsvac


--Using temp table
Drop table if exists #percentpopvac
Create Table #percentpopvac
(continent varchar(255),
 location varchar(255),
 date datetime,
 population numeric,
 new_vaccinations numeric,
 Rollingpeoplevaccinated numeric
 )

 Insert into #percentpopvac
 SELECT dea.continent, dea.location, dea.date, dea.population, vac.new_vaccinations--dea.total_cases, dea.new_cases, dea.total_deaths, dea.new_deaths, dea.new_tests, dea.total_tests, dea.positive_rate, vac.total_vaccinations, vac.new_vaccinations, dea.population
, sum(cast(vac.new_vaccinations as int)) over (partition by dea.location order by dea.location,dea.date) as Rollingpeoplevaccinated
FROM [PortfolioProject1].[dbo].[CovidDeaths$] as dea
join [PortfolioProject1].[dbo].[CovidVaccinations$] as vac
  on dea.location =  vac.location 
  and dea.date =  vac.date
where dea.continent is not null



SELECT *, (Rollingpeoplevaccinated/population)*100 
from #percentpopvac


--Creatibg view to store data for later visualasations
create view percentpopvac as

SELECT dea.continent, dea.location, dea.date, dea.population, vac.new_vaccinations--dea.total_cases, dea.new_cases, dea.total_deaths, dea.new_deaths, dea.new_tests, dea.total_tests, dea.positive_rate, vac.total_vaccinations, vac.new_vaccinations, dea.population
, sum(cast(vac.new_vaccinations as int)) over (partition by dea.location order by dea.location,dea.date) as Rollingpeoplevaccinated
FROM [PortfolioProject1].[dbo].[CovidDeaths$] as dea
join [PortfolioProject1].[dbo].[CovidVaccinations$] as vac
  on dea.location =  vac.location 
  and dea.date =  vac.date
where dea.continent is not null

SELECT *, (Rollingpeoplevaccinated/population)*100 
from percentpopvac



